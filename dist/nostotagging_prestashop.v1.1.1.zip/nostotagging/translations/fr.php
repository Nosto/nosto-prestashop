<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{nostotagging}prestashop>nostotagging_285cb38d23cdf651e85a327334a9e67d'] = 'Les données du compte doivent être configurées avant l\'utilisation de ce module.';
$_MODULE['<{nostotagging}prestashop>nostotagging_60178e9bea87234e2bc0bd22a09b20a4'] = 'Recommandations personnalisées';
$_MODULE['<{nostotagging}prestashop>nostotagging_70b3fe372fa6162e116fd7244c9d1bba'] = 'Intègre les fonctionnalités de marketing automatisé Nosto';
$_MODULE['<{nostotagging}prestashop>nostotagging_dc5be3e3ca8cc71dd53e412ad625ecd4'] = 'Le nom du compte doit être renseigné';
$_MODULE['<{nostotagging}prestashop>nostotagging_310d1e088e81ab4bbc800099de257ef2'] = 'Les paramètres d\'utilisation des bandeaux de recommandation par défaut sont incorrects.';
$_MODULE['<{nostotagging}prestashop>nostotagging_b90b0f2fc8d4ec07910ae449a694b874'] = 'Les paramètres d\'ajout des recommandations aux pages catégories et de recherche sont non valides.';
$_MODULE['<{nostotagging}prestashop>nostotagging_e60263ac381ae4a9ad460a5c706b9b5a'] = 'Paramètres enregistrés';
$_MODULE['<{nostotagging}prestashop>nostotagging_d471d1247d1daf057584fe33cabe647b'] = 'Vous n\'avez pas configuré de compte Nosto. Veuillez visiter www.nosto.com pour créer un compte et commencer à utiliser Nosto.';
$_MODULE['<{nostotagging}prestashop>nostotagging_52f4393e1b52ba63e27310ca92ba098c'] = 'Paramètres généraux';
$_MODULE['<{nostotagging}prestashop>nostotagging_aa90c53280582695f3d4b8ac2ec17a8b'] = 'Nom du compte';
$_MODULE['<{nostotagging}prestashop>nostotagging_c125e31a0f4349440c57b488af62c969'] = 'Votre nom de compte Nosto';
$_MODULE['<{nostotagging}prestashop>nostotagging_33f04ded50801147c28937fe34c61eef'] = 'Utilisez les bandeaux de recommandation Nosto par défaut';
$_MODULE['<{nostotagging}prestashop>nostotagging_58db9b260bd6b54632b12b602f809e5c'] = 'Utilisez les bandeaux de recommandation Nosto par défaut pour afficher les recommandations de produits';
$_MODULE['<{nostotagging}prestashop>nostotagging_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Activé';
$_MODULE['<{nostotagging}prestashop>nostotagging_b9f5c797ebbf55adccdd8539a65a0241'] = 'Désactivé';
$_MODULE['<{nostotagging}prestashop>nostotagging_7c9448295ab4e9e281e95b42160f0de8'] = 'Ajouter des recommandations aux pages catégories et de recherche';
$_MODULE['<{nostotagging}prestashop>nostotagging_171055ff8d48ac6345218829a358fbc9'] = 'Ajoute automatiquement les recommandations aux pages catégories et de recherche sans modifier le thème. Pour un contrôle total des bandeaux de recommandation, vous devez désactiver cette option et ajouter les hooks aux fichiers templates de votre thème en suivant les instructions du module.';
$_MODULE['<{nostotagging}prestashop>nostotagging_c9cc8cce247e49bae79f15173ce97354'] = 'Enregistrer';
